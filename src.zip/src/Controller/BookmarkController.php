<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\UrlHelper;
use Doctrine\Persistence\ManagerRegistry;
use App\Entity\Bookmark;

class BookmarkController extends AbstractController
{
    /**
     * @Route("/bookmark/create", name="create_bookmark", methods={"POST"})
     */

    public function create_bookmark(ManagerRegistry $doctrine, Request $request, UrlHelper $urlHelper): Response
    {
        $response = new Response();
        $response->headers->set('Server', 'ExoAPICRUDREST');

        $name = $request->get("name");
        $description = $request->get("description");
        $url = $request->get("url");

        if (!isset($url) or !isset($name)) {
            $response->setStatusCode(Response::HTTP_BAD_REQUEST, "url and name must not be empty");
            return $response;
        }
        ;


        $entityManager = $doctrine->getManager();
        $bookmark = new Bookmark();
        $bookmark->setName($name);
        $bookmark->setDescription($description);
        $bookmark->setUrl($url);

        $entityManager->persist($bookmark);

        $entityManager->flush();

        $id = $bookmark->getId();

        $response->setStatusCode(Response::HTTP_CREATED, "Created");
        $response->headers->set("Location", $urlHelper->getAbsoluteUrl('/api/bookmarks/' . $id));

        return $response;
    }

    /**
     * @Route("/bookmark", name="app_bookmark")
     */
    public function index(): JsonResponse
    {
        return $this->json([
            'message' => 'Welcome to your new controller!',
            'path' => 'src/Controller/BookmarkController.php',
        ]);
    }
}
